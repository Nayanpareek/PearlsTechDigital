export default function GridBackground() {
  return (
    <div 
      className="absolute inset-0 pointer-events-none -z-20 opacity-20"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 191, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 191, 255, 0.1) 1px, transparent 1px)`,
        backgroundSize: '40px 40px',
        maskImage: 'linear-gradient(to bottom, black 40%, transparent 100%)',
        WebkitMaskImage: 'linear-gradient(to bottom, black 40%, transparent 100%)'
      }}
    />
  );
}