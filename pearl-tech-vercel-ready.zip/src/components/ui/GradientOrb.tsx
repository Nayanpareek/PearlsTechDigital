import { motion } from "framer-motion";

interface GradientOrbProps {
  color?: string;
  size?: number;
  className?: string;
  delay?: number;
}

export default function GradientOrb({ 
  color = "rgba(0, 191, 255, 0.15)", 
  size = 400, 
  className = "",
  delay = 0 
}: GradientOrbProps) {
  return (
    <motion.div
      className={`absolute rounded-full pointer-events-none mix-blend-screen blur-[80px] -z-10 ${className}`}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle, ${color} 0%, transparent 70%)`
      }}
      animate={{
        y: [0, -30, 0],
        x: [0, 20, 0],
      }}
      transition={{
        duration: 8,
        repeat: Infinity,
        ease: "easeInOut",
        delay
      }}
    />
  );
}