import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function ParticleField() {
  const [particles, setParticles] = useState<{ id: number; x: number; size: number; duration: number; delay: number; opacity: number }[]>([]);

  useEffect(() => {
    const particleCount = 25;
    const newParticles = Array.from({ length: particleCount }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: Math.random() * 4 + 1,
      duration: Math.random() * 10 + 10,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.4 + 0.2
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none -z-10">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute bottom-[-10px] rounded-full bg-cyan-400"
          style={{
            left: `${p.x}%`,
            width: p.size,
            height: p.size,
            opacity: p.opacity,
            boxShadow: "0 0 10px 2px rgba(0, 191, 255, 0.5)"
          }}
          animate={{
            y: [0, -1000],
            opacity: [p.opacity, p.opacity * 2, 0]
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            delay: p.delay,
            ease: "linear"
          }}
        />
      ))}
    </div>
  );
}