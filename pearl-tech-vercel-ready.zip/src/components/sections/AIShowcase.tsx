import { motion } from "framer-motion";
import { Mail, Brain, Workflow, LineChart, ArrowRight } from "lucide-react";

export default function AIShowcase() {
  const steps = [
    {
      id: "input",
      icon: Mail,
      label: "Customer inquiry email",
      title: "INPUT",
      color: "text-blue-400",
      borderColor: "border-blue-400/30",
      bg: "bg-blue-400/10"
    },
    {
      id: "processing",
      icon: Brain,
      label: "Sentiment analysis + intent detection",
      title: "AI PROCESSING",
      color: "text-primary",
      borderColor: "border-primary/30",
      bg: "bg-primary/10"
    },
    {
      id: "automation",
      icon: Workflow,
      label: "Route to CRM, create ticket, notify team",
      title: "AUTOMATION",
      color: "text-secondary",
      borderColor: "border-secondary/30",
      bg: "bg-secondary/10"
    },
    {
      id: "outcome",
      icon: LineChart,
      label: "80% faster response, 40% higher satisfaction",
      title: "BUSINESS OUTCOME",
      color: "text-accent",
      borderColor: "border-accent/30",
      bg: "bg-accent/10"
    }
  ];

  return (
    <section className="py-16 relative overflow-hidden">
      <div className="container mx-auto px-6">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">See AI in Action</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">Watch how our automated pipelines transform manual processes into intelligent workflows.</p>
        </motion.div>

        <div className="relative max-w-5xl mx-auto">
          {/* Connecting Line (Desktop) */}
          <div className="hidden lg:block absolute top-[100px] left-[10%] right-[10%] h-[2px] bg-white/10 z-0">
            <motion.div 
              className="h-full bg-gradient-to-r from-blue-400 via-primary to-accent shadow-[0_0_15px_rgba(0,191,255,0.8)]"
              initial={{ width: 0 }}
              whileInView={{ width: "100%" }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 relative z-10">
            {steps.map((step, i) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: i * 0.4, type: "spring" }}
                className="flex flex-col items-center text-center relative"
              >
                <div className={`w-14 h-14 rounded-2xl ${step.bg} ${step.borderColor} border flex items-center justify-center mb-4 shadow-lg backdrop-blur-sm relative group`}>
                  <div className={`absolute inset-0 rounded-2xl bg-current opacity-20 animate-ping`} style={{ color: "inherit" }} />
                  <step.icon className={`w-7 h-7 ${step.color}`} strokeWidth={1.5} />
                </div>
                
                <h4 className={`text-sm font-bold tracking-wider mb-3 ${step.color}`}>{step.title}</h4>
                
                <div className="glass-card p-4 rounded-xl text-sm text-white/90 border border-white/5 w-full">
                  {step.label}
                </div>
                
                {/* Mobile Connector */}
                {i < steps.length - 1 && (
                  <div className="lg:hidden my-4 text-white/20">
                    <ArrowRight className="rotate-90 w-6 h-6" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}