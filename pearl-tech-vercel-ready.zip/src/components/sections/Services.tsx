import { motion } from "framer-motion";
import { Globe2, Brain, Workflow } from "lucide-react";
import { SiSalesforce } from "react-icons/si";
import { Link } from "wouter";

type LucideIconComponent = React.ComponentType<{ className?: string; strokeWidth?: number }>;
type SiIconComponent = React.ComponentType<{ size?: number; color?: string }>;

type Service = {
  id: string;
  title: string;
  description: string;
  tags: string[];
  iconType: "lucide" | "si";
  iconColor: string;
  glowColor: string;
  lucideIcon?: LucideIconComponent;
  siIcon?: SiIconComponent;
};

const services: Service[] = [
  {
    id: "web-dev",
    title: "Web Development",
    iconType: "lucide",
    lucideIcon: Globe2,
    iconColor: "#00BFFF",
    glowColor: "rgba(0, 191, 255, 0.2)",
    description: "Enterprise-grade web applications built with modern frameworks. React, Next.js, TypeScript — scalable, fast, and built to last.",
    tags: ["React", "Next.js", "TypeScript", "Node.js"]
  },
  {
    id: "ai-automation",
    title: "AI Automation Solutions",
    iconType: "lucide",
    lucideIcon: Brain,
    iconColor: "#A78BFA",
    glowColor: "rgba(167, 139, 250, 0.2)",
    description: "Intelligent automation that eliminates manual workflows, reduces costs, and accelerates business outcomes through AI.",
    tags: ["OpenAI", "Python", "Automation", "ML"]
  },
  {
    id: "salesforce",
    title: "Salesforce Solutions",
    iconType: "si",
    siIcon: SiSalesforce as SiIconComponent,
    iconColor: "#00A1E0",
    glowColor: "rgba(0, 161, 224, 0.2)",
    description: "Complete Salesforce implementation, customization, and integration. Sales Cloud, Service Cloud, Marketing Cloud.",
    tags: ["Sales Cloud", "Service Cloud", "Marketing Cloud"]
  },
  {
    id: "appian",
    title: "Appian Solutions",
    iconType: "lucide",
    lucideIcon: Workflow,
    iconColor: "#00FF87",
    glowColor: "rgba(0, 255, 135, 0.2)",
    description: "Low-code enterprise automation with Appian BPM. Digital transformation for complex enterprise workflows.",
    tags: ["BPM", "Low-Code", "Digital Transformation"]
  }
];

function ServiceIcon({ service }: { service: Service }) {
  if (service.iconType === "si" && service.siIcon) {
    const Icon = service.siIcon;
    return <Icon size={28} color={service.iconColor} />;
  }
  if (service.lucideIcon) {
    const Icon = service.lucideIcon;
    return <Icon className="w-7 h-7" style={{ color: service.iconColor }} strokeWidth={1.5} />;
  }
  return null;
}

export default function Services() {
  return (
    <section id="services" className="py-16 relative">
      <div className="container mx-auto px-6">

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">What We Build</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, i) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, type: "spring", stiffness: 50 }}
              className="glass-card rounded-2xl p-8 relative group overflow-hidden border border-white/5 hover:border-white/20 transition-all duration-500"
              data-testid={`service-card-${service.id}`}
            >
              {/* Hover gradient background */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background: `radial-gradient(circle at 20% 20%, ${service.glowColor}, transparent 60%)` }}
              />

              <div className="relative z-10 flex flex-col h-full">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-6 border transition-all duration-500 group-hover:scale-110"
                  style={{
                    background: `${service.glowColor}`,
                    borderColor: `${service.iconColor}30`,
                    boxShadow: `0 0 0 0 ${service.iconColor}00`,
                  }}
                >
                  <ServiceIcon service={service} />
                </div>

                <h3 className="text-2xl font-heading font-semibold text-white mb-4">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed mb-8 flex-grow">
                  {service.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-8">
                  {service.tags.map((tag, idx) => (
                    <span key={idx} className="px-3 py-1 text-xs font-medium bg-white/5 border border-white/10 rounded-full text-white/80">
                      {tag}
                    </span>
                  ))}
                </div>

                <Link href="#contact" className="font-medium flex items-center gap-2 group/link w-fit transition-colors" style={{ color: service.iconColor }}>
                  Learn More
                  <span className="group-hover/link:translate-x-1 transition-transform">→</span>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
