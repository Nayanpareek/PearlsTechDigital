import { motion } from "framer-motion";
import { Factory, Briefcase } from "lucide-react";

export default function TransformationExamples() {
  return (
    <section className="py-16 relative bg-black/40">
      <div className="container mx-auto px-6">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">Real-World Solutions</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">How we engineer efficiency across different sectors.</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          
          {/* Card 1 */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card rounded-2xl p-6 lg:p-8 border-t border-t-primary/30 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
              <Factory size={120} />
            </div>
            
            <div className="relative z-10">
              <div className="bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm font-semibold inline-block mb-6">Manufacturing</div>
              <h3 className="text-xl font-bold text-white mb-4">Quality Control Automation</h3>
              
              <div className="space-y-4 mb-8">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Challenge</div>
                  <p className="text-white/80">Manual quality control causing delays and high defect rates.</p>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Solution</div>
                  <p className="text-white/80">AI-powered visual inspection + automated reporting pipeline.</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/10">
                <div>
                  <div className="text-2xl font-bold text-primary mb-1">65%</div>
                  <div className="text-xs text-muted-foreground">Defect Reduction</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary mb-1">3x</div>
                  <div className="text-xs text-muted-foreground">Faster Inspection</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary mb-1">24/7</div>
                  <div className="text-xs text-muted-foreground">Real-time Data</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Card 2 */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card rounded-2xl p-6 lg:p-8 border-t border-t-secondary/30 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
              <Briefcase size={120} />
            </div>
            
            <div className="relative z-10">
              <div className="bg-secondary/20 text-secondary px-4 py-1.5 rounded-full text-sm font-semibold inline-block mb-6">Professional Services</div>
              <h3 className="text-xl font-bold text-white mb-4">Client Onboarding</h3>
              
              <div className="space-y-4 mb-8">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Challenge</div>
                  <p className="text-white/80">Manual client onboarding taking weeks with paper-based processes.</p>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Solution</div>
                  <p className="text-white/80">Appian BPM automation + Salesforce integration + AI document processing.</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10">
                <div>
                  <div className="text-2xl font-bold text-secondary mb-1">90%</div>
                  <div className="text-xs text-muted-foreground">Faster Onboarding</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-secondary mb-1">Zero</div>
                  <div className="text-xs text-muted-foreground">Manual Entry</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-secondary mb-1">100%</div>
                  <div className="text-xs text-muted-foreground">Audit Trail</div>
                </div>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}