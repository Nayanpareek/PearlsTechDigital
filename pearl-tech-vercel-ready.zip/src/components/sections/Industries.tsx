import { motion } from "framer-motion";
import { Laptop, Activity, Factory, Home, ShoppingCart, Briefcase, Users, Building } from "lucide-react";

const industries = [
  { name: "Technology", icon: Laptop },
  { name: "Healthcare", icon: Activity },
  { name: "Manufacturing", icon: Factory },
  { name: "Real Estate", icon: Home },
  { name: "E-Commerce", icon: ShoppingCart },
  { name: "Agencies", icon: Briefcase },
  { name: "Professional Services", icon: Users },
  { name: "Enterprise", icon: Building },
];

export default function Industries() {
  return (
    <section id="industries" className="py-16">
      <div className="container mx-auto px-6 text-center">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-3">Industries We Serve</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm">Tailored technology solutions designed for the specific challenges of your sector.</p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {industries.map((ind, i) => (
            <motion.div
              key={ind.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-card p-4 md:p-5 rounded-2xl flex flex-col items-center justify-center gap-3 group cursor-pointer"
            >
              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300">
                <ind.icon className="w-6 h-6 text-white/70 group-hover:text-primary transition-colors" strokeWidth={1.5} />
              </div>
              <span className="text-white font-medium text-xs md:text-sm">{ind.name}</span>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}