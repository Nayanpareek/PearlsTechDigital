import { motion } from "framer-motion";
import { BrainCircuit, Building2, Cloud, Globe2 } from "lucide-react";

const solutions = [
  {
    title: "AI Automation",
    description: "Intelligent process automation",
    icon: BrainCircuit,
    color: "text-primary"
  },
  {
    title: "Enterprise Solutions",
    description: "Fortune 500-grade architecture",
    icon: Building2,
    color: "text-secondary"
  },
  {
    title: "Salesforce Expertise",
    description: "Certified CRM specialists",
    icon: Cloud,
    color: "text-accent"
  },
  {
    title: "Global Delivery",
    description: "Teams across 4 continents",
    icon: Globe2,
    color: "text-white"
  }
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100 } }
};

export default function TrustedSolutions() {
  return (
    <section className="py-14 relative z-10">
      <div className="container mx-auto px-6">
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5"
        >
          {solutions.map((sol, index) => (
            <motion.div 
              key={index}
              variants={item}
              className="glass-card p-6 rounded-2xl group hover:glow-border transition-all duration-300 relative overflow-hidden"
              data-testid={`trusted-solution-${index}`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <sol.icon className={`w-9 h-9 mb-4 ${sol.color} opacity-80 group-hover:opacity-100 transition-opacity group-hover:scale-110 duration-500`} strokeWidth={1.5} />
              <h3 className="text-base font-heading font-semibold text-white mb-1">{sol.title}</h3>
              <p className="text-muted-foreground text-sm">{sol.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}