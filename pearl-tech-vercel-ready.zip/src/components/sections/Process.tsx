import { motion } from "framer-motion";

const steps = [
  { num: "01", title: "Discovery", desc: "Deep dive into your business goals and current technological landscape." },
  { num: "02", title: "Strategy", desc: "Roadmap & architecture planning tailored to your enterprise requirements." },
  { num: "03", title: "Development", desc: "Agile sprints, transparent progress, and continuous feedback integration." },
  { num: "04", title: "Automation", desc: "AI integration & workflow setup for maximum operational efficiency." },
  { num: "05", title: "Launch", desc: "Rigorous testing, secure deployment, and smooth transition." },
  { num: "06", title: "Support", desc: "Ongoing optimization, maintenance, and strategic growth." }
];

export default function Process() {
  return (
    <section id="process" className="py-16 relative bg-black/20">
      <div className="container mx-auto px-6 max-w-4xl">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">How We Work</h2>
          <p className="text-muted-foreground">A proven methodology for enterprise success.</p>
        </motion.div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-[28px] md:left-1/2 md:-translate-x-1/2 top-0 bottom-0 w-[2px] bg-white/10">
            <motion.div 
              className="absolute top-0 w-full bg-gradient-to-b from-primary via-secondary to-accent"
              initial={{ height: 0 }}
              whileInView={{ height: "100%" }}
              viewport={{ once: true }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />
          </div>

          <div className="flex flex-col gap-8">
            {steps.map((step, i) => {
              const isEven = i % 2 !== 0;
              return (
                <div key={step.num} className={`relative flex items-center md:justify-between ${isEven ? 'md:flex-row-reverse' : ''}`}>
                  
                  {/* Number Circle */}
                  <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-14 h-14 rounded-full bg-background border-2 border-primary flex items-center justify-center z-10 shadow-[0_0_15px_rgba(0,191,255,0.4)]">
                    <span className="font-heading font-bold text-white">{step.num}</span>
                  </div>

                  {/* Content Card */}
                  <motion.div 
                    initial={{ opacity: 0, x: isEven ? 50 : -50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className={`w-full md:w-[45%] pl-24 md:pl-0 ${isEven ? 'md:pr-16 md:text-right' : 'md:pl-16'}`}
                  >
                    <div className="glass-card p-6 rounded-2xl hover:border-primary/50 transition-colors">
                      <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
                      <p className="text-muted-foreground">{step.desc}</p>
                    </div>
                  </motion.div>

                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}