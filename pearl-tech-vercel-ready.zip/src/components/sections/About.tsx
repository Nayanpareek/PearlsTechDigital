import { motion } from "framer-motion";

export default function About() {
  return (
    <section id="about" className="py-16 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col gap-4"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-2">About Pearl Tech</h2>
            
            <div className="border-l-4 border-primary pl-5 py-2 my-2">
              <h3 className="text-base font-semibold text-white mb-1">Mission</h3>
              <p className="text-muted-foreground">Empower businesses through innovative technology.</p>
            </div>
            
            <div className="border-l-4 border-secondary pl-5 py-2 my-2">
              <h3 className="text-base font-semibold text-white mb-1">Vision</h3>
              <p className="text-muted-foreground">Become a trusted global technology partner.</p>
            </div>

            <p className="text-white/80 leading-relaxed text-sm mt-2">
              Pearl Tech is more than a consulting firm; we are architects of digital transformation. We bridge the gap between complex enterprise challenges and cutting-edge technological solutions. 
            </p>
            <p className="text-white/80 leading-relaxed text-sm">
              By leveraging AI, robust web frameworks, and enterprise platforms like Salesforce and Appian, we build scalable systems that drive growth, efficiency, and long-term success.
            </p>
          </motion.div>

          {/* Abstract Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative h-[300px] lg:h-[380px] w-full rounded-3xl overflow-hidden glass-card flex items-center justify-center"
          >
            {/* Rotating gradient background */}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute inset-[-50%] bg-[conic-gradient(from_0deg,transparent_0_340deg,rgba(0,191,255,0.3)_360deg)]"
            />
            
            {/* Geometric Art */}
            <div className="relative z-10 w-48 h-48 border border-white/20 rounded-full flex items-center justify-center p-6 backdrop-blur-md">
              <motion.div 
                animate={{ rotate: -360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="w-full h-full border border-primary/40 rounded-full flex items-center justify-center p-6"
              >
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                  className="w-full h-full border border-secondary/60 rounded-full flex items-center justify-center p-4"
                >
                  <div className="w-full h-full bg-gradient-to-br from-primary to-accent rounded-full blur-[10px] opacity-80" />
                </motion.div>
              </motion.div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}