import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function ContactCTA() {
  return (
    <section id="contact" className="relative py-32 overflow-hidden">
      {/* Deep animated background */}
      <div className="absolute inset-0 bg-primary/5 -z-20" />
      <motion.div 
        className="absolute inset-0 opacity-30 -z-10 bg-[radial-gradient(circle_at_50%_50%,rgba(0,191,255,0.4)_0%,transparent_50%)]"
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] -z-10 [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_80%)]" />

      <div className="container mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <h2 className="text-5xl md:text-6xl font-heading font-bold text-white mb-6 tracking-tight">
            Ready To Transform Your Business?
          </h2>
          <p className="text-xl text-white/80 mb-10 leading-relaxed">
            Join companies across India, USA, UK, and Australia that trust Pearl Tech to engineer their future. Let's build something extraordinary together.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="w-full sm:w-auto bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity text-white border-0 h-14 px-8 text-lg rounded-xl shadow-[0_0_20px_rgba(0,191,255,0.3)]" asChild>
              <a href="mailto:pearltech1@outlook.com" data-testid="button-cta-primary">Schedule a Consultation</a>
            </Button>
            <Button size="lg" variant="outline" className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10 h-14 px-8 text-lg rounded-xl" asChild>
              <a href="mailto:pearltech1@outlook.com" data-testid="button-cta-secondary">Book a Call</a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}