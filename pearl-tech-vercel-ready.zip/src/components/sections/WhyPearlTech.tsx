import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const features = [
  { title: "Future Ready Solutions", desc: "Built with tomorrow's standards" },
  { title: "Enterprise Expertise", desc: "Fortune 500 methodology" },
  { title: "AI Innovation", desc: "GPT-powered workflows" },
  { title: "Scalable Architecture", desc: "Grows with your business" },
  { title: "Fast Delivery", desc: "Agile sprints, rapid launches" },
  { title: "Long-Term Partnership", desc: "We grow with you" },
];

export default function WhyPearlTech() {
  return (
    <section className="py-16 relative overflow-hidden bg-white/[0.02]">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-3xl h-[400px] bg-primary/5 blur-[100px] rounded-full pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          
          <div className="lg:col-span-1">
            <motion.h2 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-heading font-bold text-white mb-4"
            >
              Why Companies Choose <span className="text-primary">Pearl Tech</span>
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-muted-foreground text-base mb-6"
            >
              We don't just build software. We engineer competitive advantages for enterprises ready to scale.
            </motion.p>
          </div>

          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-background/40 backdrop-blur-sm border border-white/5 p-6 rounded-2xl hover:bg-white/5 transition-colors flex items-start gap-4"
              >
                <div className="mt-1 bg-gradient-to-br from-primary to-secondary rounded-full p-[2px]">
                  <div className="bg-background rounded-full p-1">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                  </div>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">{feature.title}</h4>
                  <p className="text-muted-foreground text-sm">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}