import { motion } from "framer-motion";
import { MapPin } from "lucide-react";

export default function GlobalReach() {
  const locations = [
    { name: "USA", top: "30%", left: "20%", delay: 0.2 },
    { name: "UK", top: "25%", left: "48%", delay: 0.4 },
    { name: "India", top: "45%", left: "70%", delay: 0.6 },
    { name: "Australia", top: "75%", left: "85%", delay: 0.8 },
  ];

  return (
    <section className="py-24 relative overflow-hidden bg-black/30">
      <div className="container mx-auto px-6">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-white mb-4">Helping Businesses Scale Across Borders</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">Global expertise delivered locally. Operating across four continents to provide continuous, enterprise-grade support.</p>
        </motion.div>

        <div className="relative w-full max-w-5xl mx-auto aspect-[2/1] min-h-[300px]">
          {/* Abstract Map Background (CSS driven) */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,191,255,0.1)_0%,transparent_70%)]" />
          
          <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
             <pattern id="dot-pattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
               <circle cx="2" cy="2" r="1.5" fill="currentColor" className="text-primary"/>
             </pattern>
             <rect x="0" y="0" width="100%" height="100%" fill="url(#dot-pattern)"/>
          </svg>

          {/* Location Markers */}
          {locations.map((loc, i) => (
            <motion.div
              key={loc.name}
              className="absolute flex flex-col items-center justify-center transform -translate-x-1/2 -translate-y-1/2"
              style={{ top: loc.top, left: loc.left }}
              initial={{ opacity: 0, scale: 0 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: loc.delay, type: "spring" }}
            >
              <div className="relative">
                {/* Ping animation */}
                <motion.div 
                  className="absolute inset-0 rounded-full bg-primary"
                  animate={{ scale: [1, 2.5], opacity: [0.7, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeOut", delay: loc.delay }}
                />
                <div className="w-4 h-4 bg-primary rounded-full border-2 border-background relative z-10 shadow-[0_0_10px_rgba(0,191,255,1)]" />
              </div>
              <div className="mt-2 glass-card px-3 py-1 rounded-full border border-white/10 text-xs font-semibold text-white whitespace-nowrap backdrop-blur-md">
                <MapPin className="w-3 h-3 inline-block mr-1 text-primary" />
                {loc.name}
              </div>
            </motion.div>
          ))}

          {/* Connection Lines (Abstract SVG) */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0" viewBox="0 0 1000 500" preserveAspectRatio="none">
            <motion.path 
              d="M 200 150 Q 350 75 480 125 Q 600 150 700 225 Q 800 300 850 375" 
              fill="none" 
              stroke="rgba(0, 191, 255, 0.3)" 
              strokeWidth="2"
              strokeDasharray="5,5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 3, ease: "easeInOut" }}
            />
          </svg>
        </div>

      </div>
    </section>
  );
}