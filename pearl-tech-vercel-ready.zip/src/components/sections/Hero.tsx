import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import GridBackground from "@/components/ui/GridBackground";
import GradientOrb from "@/components/ui/GradientOrb";
import ParticleField from "@/components/ui/ParticleField";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[100dvh] flex items-center justify-center pt-20 overflow-hidden">
      <GridBackground />
      <ParticleField />
      
      {/* Glow effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[var(--gradient-hero)] -z-10" />
      
      <GradientOrb color="rgba(0, 191, 255, 0.15)" size={500} className="top-1/4 left-[10%]" delay={0} />
      <GradientOrb color="rgba(59, 130, 246, 0.15)" size={600} className="top-1/3 right-[5%]" delay={2} />

      <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center relative z-10">
        
        {/* Left: Content */}
        <div className="flex flex-col gap-4">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-3xl lg:text-5xl font-bold font-heading leading-tight tracking-tight text-white"
          >
            Transforming Businesses Through <span className="gradient-text glow-text">AI, Automation</span> & Modern Technology
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="text-sm lg:text-base text-muted-foreground leading-relaxed max-w-xl"
          >
            Pearl Tech helps businesses scale through modern web development, AI automation, Salesforce solutions, and Appian-powered digital transformation.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-wrap items-center gap-3 mt-2"
          >
            <Button size="default" className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity text-white border-0 h-10 px-6 text-sm" asChild>
              <a href="mailto:pearltech1@outlook.com" data-testid="button-hero-primary">Schedule a Consultation</a>
            </Button>
            <Button size="default" variant="outline" className="border-primary/50 text-white hover:bg-primary/10 h-10 px-6 text-sm" asChild>
              <a href="mailto:pearltech1@outlook.com" data-testid="button-hero-secondary">Book a Call</a>
            </Button>
          </motion.div>
        </div>

        {/* Right: Abstract UI Mockup */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, rotateY: 5 }}
          animate={{ opacity: 1, scale: 1, rotateY: 0 }}
          transition={{ duration: 1, delay: 0.3, type: "spring", stiffness: 100, damping: 20 }}
          className="relative lg:h-[360px] w-full max-w-md mx-auto perspective-1000"
        >
          <div className="glass-card rounded-2xl p-6 w-full h-full shadow-2xl relative overflow-hidden flex flex-col gap-6 transform-gpu rotate-y-[-10deg] rotate-x-[5deg]">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary rounded-full animate-pulse" />
                </div>
                <div className="flex flex-col gap-1">
                  <div className="w-24 h-2 bg-white/20 rounded" />
                  <div className="w-16 h-2 bg-white/10 rounded" />
                </div>
              </div>
              <div className="flex gap-2">
                <div className="w-2 h-2 rounded-full bg-destructive" />
                <div className="w-2 h-2 rounded-full bg-yellow-500" />
                <div className="w-2 h-2 rounded-full bg-accent" />
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="text-xs text-muted-foreground mb-2">System Efficiency</div>
                <div className="text-3xl font-heading font-bold text-primary">99.9%</div>
                <div className="mt-2 w-full h-1 bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-primary" 
                    initial={{ width: 0 }} 
                    animate={{ width: "99.9%" }} 
                    transition={{ duration: 1.5, delay: 1 }}
                  />
                </div>
              </div>
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="text-xs text-muted-foreground mb-2">Processing Time</div>
                <div className="text-3xl font-heading font-bold text-accent">0.12s</div>
                <div className="mt-2 flex gap-1 h-4 items-end">
                  {[40, 70, 45, 90, 60, 30, 80].map((h, i) => (
                    <motion.div 
                      key={i}
                      className="w-full bg-accent/80 rounded-t-sm"
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ duration: 0.5, delay: 1 + (i * 0.1) }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Graph Area */}
            <div className="flex-grow bg-white/5 rounded-xl border border-white/10 p-4 relative overflow-hidden">
              <svg viewBox="0 0 100 50" className="w-full h-full preserve-3d" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="rgba(0, 191, 255, 0)" />
                    <stop offset="50%" stopColor="rgba(0, 191, 255, 1)" />
                    <stop offset="100%" stopColor="rgba(59, 130, 246, 1)" />
                  </linearGradient>
                </defs>
                <motion.path
                  d="M0,40 Q20,30 40,40 T80,20 T100,5"
                  fill="none"
                  stroke="url(#lineGrad)"
                  strokeWidth="2"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 2, delay: 1.5, ease: "easeInOut" }}
                  style={{ filter: "drop-shadow(0 0 4px rgba(0,191,255,0.5))" }}
                />
              </svg>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
}