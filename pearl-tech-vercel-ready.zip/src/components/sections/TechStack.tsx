import { motion } from "framer-motion";
import { SiReact, SiNextdotjs, SiTypescript, SiNodedotjs, SiPython, SiOpenai, SiSalesforce } from "react-icons/si";
import { Cloud, Server } from "lucide-react";

const techCategories = [
  {
    name: "Frontend",
    items: [
      { name: "React", icon: SiReact, color: "#61DAFB" },
      { name: "Next.js", icon: SiNextdotjs, color: "#FFFFFF" },
      { name: "TypeScript", icon: SiTypescript, color: "#3178C6" }
    ]
  },
  {
    name: "Backend",
    items: [
      { name: "Node.js", icon: SiNodedotjs, color: "#339933" },
      { name: "Python", icon: SiPython, color: "#3776AB" }
    ]
  },
  {
    name: "Cloud",
    items: [
      { name: "AWS", icon: null, textLogo: "AWS", color: "#FF9900", lucideIcon: Cloud },
      { name: "Azure", icon: null, textLogo: "Azure", color: "#0078D4", lucideIcon: Server }
    ]
  },
  {
    name: "Enterprise & AI",
    items: [
      { name: "OpenAI", icon: SiOpenai, color: "#412991" },
      { name: "Salesforce", icon: SiSalesforce, color: "#00A1E0" },
      { name: "Appian", icon: null, textLogo: "Appian", color: "#002F6C" }
    ]
  }
];

export default function TechStack() {
  return (
    <section className="py-16 relative overflow-hidden">
      <div className="container mx-auto px-6">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">Built With Best-in-Class Technology</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {techCategories.map((category, i) => (
            <div key={category.name} className="flex flex-col gap-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest text-center mb-4">{category.name}</h3>
              <div className="flex flex-col gap-3">
                {category.items.map((tech, j) => (
                  <motion.div
                    key={tech.name}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: (i * 0.1) + (j * 0.1) }}
                    whileHover={{ scale: 1.05 }}
                    className="glass-card p-4 rounded-xl flex items-center gap-4 cursor-pointer hover:bg-white/5 transition-all"
                  >
                    <div className="w-10 h-10 rounded-lg bg-black/50 flex items-center justify-center border border-white/10">
                      {tech.icon ? (
                        <tech.icon size={24} style={{ color: tech.color }} />
                      ) : (
                        <span className="font-bold text-white text-xs">{tech.textLogo}</span>
                      )}
                    </div>
                    <span className="text-white font-medium">{tech.name}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}