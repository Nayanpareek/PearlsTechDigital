import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/sections/Hero";
import TrustedSolutions from "@/components/sections/TrustedSolutions";
import Services from "@/components/sections/Services";
import WhyPearlTech from "@/components/sections/WhyPearlTech";
import Industries from "@/components/sections/Industries";
import AIShowcase from "@/components/sections/AIShowcase";
import TransformationExamples from "@/components/sections/TransformationExamples";
import TechStack from "@/components/sections/TechStack";
import Process from "@/components/sections/Process";
import About from "@/components/sections/About";
import GlobalReach from "@/components/sections/GlobalReach";
import ContactCTA from "@/components/sections/ContactCTA";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-grow">
        <Hero />
        <TrustedSolutions />
        <Services />
        <WhyPearlTech />
        <Industries />
        <AIShowcase />
        <TransformationExamples />
        <TechStack />
        <Process />
        <About />
        <GlobalReach />
        <ContactCTA />
      </main>

      <Footer />
    </div>
  );
}