import { Link } from "wouter";
import { Linkedin, Instagram, Mail } from "lucide-react";
import logoPath from "@assets/logo.png";

export default function Footer() {
  return (
    <footer className="bg-background border-t border-primary/10 pt-16 pb-8 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
      
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <div className="col-span-1 md:col-span-2">
            <Link href="/">
              <div className="flex items-center gap-3 cursor-pointer mb-6" data-testid="link-footer-logo">
                <img src={logoPath} alt="Pearl Tech Logo" className="h-10 w-auto object-contain" />
                <span className="text-2xl font-heading font-bold tracking-tight text-white">Pearl Tech</span>
              </div>
            </Link>
            <p className="text-muted-foreground max-w-sm mb-6">
              Transforming businesses through enterprise-grade AI automation, web development, and low-code solutions.
            </p>
            <div className="flex gap-4">
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 text-muted-foreground hover:text-primary transition-colors" data-testid="link-social-linkedin">
                <Linkedin size={20} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 text-muted-foreground hover:text-primary transition-colors" data-testid="link-social-instagram">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6">Company</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="text-muted-foreground hover:text-primary transition-colors">Home</a></li>
              <li><a href="#about" className="text-muted-foreground hover:text-primary transition-colors">About</a></li>
              <li><a href="#services" className="text-muted-foreground hover:text-primary transition-colors">Services</a></li>
              <li><a href="#contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6">Services</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="text-muted-foreground hover:text-primary transition-colors">Web Development</a></li>
              <li><a href="#services" className="text-muted-foreground hover:text-primary transition-colors">AI Automation</a></li>
              <li><a href="#services" className="text-muted-foreground hover:text-primary transition-colors">Salesforce</a></li>
              <li><a href="#services" className="text-muted-foreground hover:text-primary transition-colors">Appian</a></li>
            </ul>
          </div>
          
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} Pearl Tech. All rights reserved.
          </p>
          <a href="mailto:pearltech1@outlook.com" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-email">
            <Mail size={16} />
            pearltech1@outlook.com
          </a>
        </div>
      </div>
    </footer>
  );
}